var searchData=
[
  ['vertex_5faggregator_2ehpp',['vertex_aggregator.hpp',['../vertex__aggregator_8hpp.html',1,'']]],
  ['vertex_5fdata_2ehpp',['vertex_data.hpp',['../vertex__data_8hpp.html',1,'']]]
];
