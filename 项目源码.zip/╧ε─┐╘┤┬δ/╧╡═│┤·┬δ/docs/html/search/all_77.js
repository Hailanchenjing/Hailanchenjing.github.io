var searchData=
[
  ['write_5fshards',['write_shards',['../classgraphchi_1_1sharder.html#acba67408a81dfaa5fdac73c1d61f4631',1,'graphchi::sharder']]]
];
