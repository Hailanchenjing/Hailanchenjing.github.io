var searchData=
[
  ['gather_5ftype',['gather_type',['../classgraphlab_1_1icontext.html#ae1699cad574dda8cdb91d639a9c82d9e',1,'graphlab::icontext']]],
  ['graph_5ftype',['graph_type',['../classgraphlab_1_1icontext.html#adeea37e06c012067a2ec57cd0d14cbac',1,'graphlab::icontext::graph_type()'],['../als__vertex__program_8hpp.html#ab9cfd2cad1698282b6c7fd7f7e7fd459',1,'graph_type():&#160;als_vertex_program.hpp']]]
];
