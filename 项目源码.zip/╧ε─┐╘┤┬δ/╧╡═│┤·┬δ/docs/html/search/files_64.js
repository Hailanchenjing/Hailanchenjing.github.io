var searchData=
[
  ['degree_5fdata_2ehpp',['degree_data.hpp',['../degree__data_8hpp.html',1,'']]]
];
