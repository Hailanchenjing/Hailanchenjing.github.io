var searchData=
[
  ['vertex_5fdata',['vertex_data',['../structvertex__data.html#a7f177e8488c52777a14aef50256dd489',1,'vertex_data']]],
  ['vertex_5fid',['vertex_id',['../classgraphchi_1_1graphchi__edge.html#a5d55d4d82a58faa5858dfb898f2258d6',1,'graphchi::graphchi_edge']]]
];
