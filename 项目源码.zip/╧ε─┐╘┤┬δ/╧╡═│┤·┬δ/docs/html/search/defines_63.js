var searchData=
[
  ['coloroutput',['COLOROUTPUT',['../logger_8hpp.html#a407629ed2d44412adc1a9fd1bf8fc35b',1,'logger.hpp']]]
];
